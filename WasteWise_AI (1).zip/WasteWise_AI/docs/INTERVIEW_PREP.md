# WasteWise AI: Interview Prep Guide

## The project in plain words

**One-line answer:** WasteWise AI helps a campus identify a waste item from a photo, put it in the right one of India's four waste streams, book a pickup, and prove whether the material was actually recovered.

**The problem.** Campuses have colour-coded bins but still end up with mixed waste. People don't know whether a greasy pizza box, a used tissue or a dead power bank is wet, dry, sanitary or special-care waste. Even when waste is sorted, nobody tracks whether it was collected or reached a recycler. Most "recycled" numbers are really just reported numbers.

**Our solution.** One app that closes the loop: scan, segregate, request pickup, collect and weigh, confirm recovery with evidence, then measure impact.

**What makes us different.** Most waste apps stop at "this is plastic". We go further:

- We decide the stream from the material **and** the item's condition. A food-soiled paper cup is wet waste, not dry.
- Every request moves through a tracked workflow: Reported, Accepted, Collected, Recovery Confirmed.
- We count material as recovered **only** when there is evidence, such as a receipt photo or slip number. Reported or collected waste is never counted as recycled.
- The AI is honest. It shows its confidence, says "not recognised" instead of guessing, and the user always confirms.

**Who it's for.** Students and staff who throw things away, housekeeping staff who collect waste, and campus administrators who need real numbers.

## How the working model works

The whole app is one Python file (`main.py`) built with Streamlit. It runs on a normal laptop with no internet, no cloud and no API key. Data is stored in a local SQLite database that survives restarts.

```
1. Scan  ->  2. Guidance  ->  3. Pickup  ->  4. Collector  ->  5. Analytics
photo to     material + 5     saved in       accept, weigh,    reported vs
material     context checks   SQLite as      confirm with      collected vs
score        decide stream    Reported       EVIDENCE          recovered kg
```

Each step hands its result to the next. Step 4 is where we differ: nothing counts as recovered without evidence.

### Step 1: AI Waste Scanner

1. The user uploads a photo or uses the webcam.
2. A pretrained image model, **EfficientNet-Lite0**, looks at the photo. It was trained by Google on ImageNet, a dataset of 1,000 everyday object types. We converted it to ONNX format so it runs fast on any laptop CPU (under 50 ms per photo).
3. The model gives a probability for each of the 1,000 object types. We mapped about 150 of them to materials. For example, *water bottle* maps to Plastic, *beer bottle* to Glass, *carton* to Cardboard, *banana* to Organic, *diaper* to Sanitary and *cellular telephone* to E-waste.
4. We add up the probabilities for each material. That sum is the **material score**.
5. The app decides how sure it is:
   - **45% or more:** shows "AI SUGGESTION" with the material.
   - **20% to 45%:** shows "LOW CONFIDENCE, PLEASE CONFIRM".
   - **Under 20%:** shows "NOT RECOGNISED" and asks the user to pick manually. It never guesses.
6. Under "Model evidence" the app shows the model's raw top-5 predictions, so anyone can see why it decided.
7. If the model file is missing or fails to load, the app says so openly and switches to manual selection. It never shows a fake prediction.

### Step 2: Smart disposal guidance

The user confirms or corrects the material, then answers five quick yes/no context checks: food or liquid on it, used for hygiene or medical purposes, broken or sharp, has a battery or electronics, held chemicals or medicines or is an aerosol.

A rules engine combines the material and the answers to choose one of India's four streams:

| Stream | Bin | Typical items | Where it goes |
| --- | --- | --- | --- |
| Wet waste | Green | Food, peels, garden waste, food-soiled paper | Campus composter or biogas |
| Dry waste | Blue | Clean plastic, paper, cardboard, metal, glass, textile | Recycler or Material Recovery Facility |
| Sanitary waste | Red / sealed bag | Diapers, pads, used tissues, bandages | Safe disposal, never recycled |
| Special-care waste | Black / special box | E-waste, batteries, medicines, aerosols, sharps | Authorised handler |

Examples of context rules: food-soiled paper moves from dry to **wet**. Anything used for hygiene becomes **sanitary**. Anything with a battery becomes **special-care**. Broken glass gets extra "wrap and label SHARP" steps.

The guidance card shows the stream, bin colour, handling steps, recovery route and whether a pickup makes sense. Hazardous, broken or low-confidence items are **flagged for human review**.

### Step 3: Pickup request

One click on "Request pickup for this item" opens a form pre-filled from the scan. The user picks a campus location or hostel, the category and an approximate weight. The request is saved as **Reported**. Every scan is also logged as AI-confirmed, AI-corrected or Manual.

### Step 4: Collector dashboard

Collectors see queues for each status and move requests forward:

1. **Accept** the request.
2. **Mark collected** and enter the weight measured on a scale.
3. **Confirm recovery** by choosing the facility, entering the recovered weight and adding evidence: an uploaded receipt or photo, a receipt number, or a clearly labelled SIMULATED demo confirmation.

The code blocks wrong moves. You can't collect before accepting or confirm before collecting. Recovered weight can't be more than collected weight. Every change is written to an audit trail.

### Step 5: Impact analytics

The dashboard shows KPI cards and charts calculated straight from the database:

- **Reported kg** (requester's estimate), **Collected kg** (weighed) and **Recovery confirmed kg**, with evidence-backed and simulated amounts shown separately.
- Pending pickups, recovery rate (recovered divided by collected), safely disposed sanitary waste, items flagged for review, and number of scans.
- Charts: waste by category, reported vs collected vs recovered per stream, daily trend, pipeline funnel and location hotspots. Data can be exported as CSV.

**Demo data:** one sidebar button loads 28 sample requests, each marked DEMO DATA. A toggle removes them from every number and chart, and they can be cleared without touching real records.

## What to say in the interview

Split the talk by strength. **Aditya** owns the story, the demo and the impact. **Krishnansu** owns the AI, the technology and the honest limitations. Either of you can answer any question, but hand over when it's the other person's area.

| Part | Who | Time | Key message |
| --- | --- | --- | --- |
| Opening: problem and solution | Aditya | 30 s | Bins exist, but nobody knows the right stream and nobody tracks recovery |
| How the AI works | Krishnansu | 40 s | Real pretrained model, offline, honest confidence, user always confirms |
| Live demo | Aditya drives, Krishnansu narrates the AI part | 90 s | Scan, guidance, pickup, collector, dashboard |
| Data integrity | Krishnansu | 20 s | Recovered counts only with evidence |
| Impact and deployment | Aditya | 20 s | Near-zero cost, runs on one campus PC |
| Close | Aditya | 10 s | From waste to resource, with proof |

### Aditya's script

**Opening:** "Every campus has colour-coded bins, and every campus still has mixed waste. People don't know whether a greasy pizza box or a dead power bank is wet, dry, sanitary or special-care. Even when they sort correctly, nobody can say whether the waste was collected or recycled. WasteWise AI closes that loop: identify, segregate, collect, and prove recovery."

**Handover:** "Krishnansu built the AI part and will explain how it decides."

**During the demo:** "I'll upload a photo... here's the suggestion and the confidence. Now I'll book a pickup for Boys Hostel A. As the collector, I accept it, weigh it, and confirm recovery with a receipt photo. Watch the dashboard: reported, collected and recovered are three separate numbers."

**Impact and close:** "It runs on one campus PC on the local network. Students scan a QR code at the bins and open it on their phones. Housekeeping staff use it as collectors. There are no cloud or API costs. Most apps stop at identifying waste. We track it until it's recovered, with proof."

### Krishnansu's script

**How the AI works:** "We use EfficientNet-Lite0, a pretrained model from Google trained on 1,000 everyday object types. It runs fully offline on the laptop in under 50 milliseconds. We mapped about 150 of those object types to materials and add up their probabilities into a material score. Above 45% we suggest a material, between 20 and 45% we ask the user to confirm, and below 20% we say 'not recognised'. We never make up a prediction, and the user always has the final say."

**Why the context checks:** "A camera can see a paper cup but not whether it's covered in food or was used for hygiene. Those change the stream, so we ask five quick questions and a rules engine decides."

**Data integrity:** "Reported weight is an estimate and collected weight is measured. Recovery only counts with evidence, recovered can never exceed collected, and simulated demo confirmations are shown separately. Sanitary waste is never counted as recovered."

**If asked about limits:** "ImageNet doesn't have classes like crushed can or flat cardboard, so those can come back as low confidence. That's why manual confirmation is built in, and fine-tuning on Indian waste photos is our first next step."

### Tips for both

- Load DEMO DATA before you go in, and test your demo item on the laptop first. A plastic bottle is the safest choice.
- If the AI says "not recognised" live, stay calm and say: "This is the honest fallback. It doesn't guess, so the user picks manually." Judges usually like this.
- Say "we" and "our". Talk about the problem before the tech.
- If you don't know an answer, say what you do know and what you would do next. Never invent a number.

## FAQ

### About the project

**What problem are you solving?**
People don't know which of the four streams an item belongs to, and nobody tracks whether sorted waste is collected or recovered. So segregation is poor and recycling numbers can't be trusted.

**What's your differentiator?**
Most apps only identify waste. We connect identification to segregation rules, pickup logistics and evidence-backed recovery, so a campus can report verified impact instead of estimates.

**Who are the users?**
Students and staff (scan and request pickups), collectors or housekeeping staff (accept, collect, confirm), and campus admins (analytics).

**What are the four streams?**
Wet (green bin: food and garden waste), dry (blue bin: clean recyclables), sanitary (sealed red bag: diapers, pads, used tissues) and special-care (e-waste, batteries, medicines, aerosols, sharps). This follows India's four-stream segregation approach.

**Why should a campus use this instead of posters on bins?**
Posters can't handle edge cases like a food-soiled cup, and they don't create any record. Our app gives item-specific guidance and creates a trackable request with measured weights.

### AI and technical

**Is the AI real, or hard-coded?**
Real. A pretrained EfficientNet-Lite0 runs locally through ONNX Runtime. The raw top-5 predictions are shown on screen as proof. Nothing is hard-coded.

**Which model, and why that one?**
EfficientNet-Lite0, trained on ImageNet (1,000 object types), from Google's MediaPipe models (Apache 2.0 licence). It's small (18 MB), accurate for its size, and runs on a CPU in under 50 ms, so it works offline on any laptop.

**Why didn't you train your own waste model?**
We had 5 hours. A rushed custom model would be less reliable than a well-tested pretrained one. The design is model-agnostic, so a model fine-tuned on waste images can be dropped in later by replacing one file.

**How do you go from 1,000 ImageNet classes to waste materials?**
We mapped about 150 relevant classes to 10 materials, for example water bottle to Plastic and carton to Cardboard. We sum the probabilities per material to get a material score. Classes we didn't map count as "unknown", which lowers the score instead of forcing a guess.

**What does the confidence number mean?**
It's the total probability the model gives to all object types that belong to that material. 45% or more gives a suggestion, 20 to 45% asks for confirmation, under 20% says not recognised.

**What happens when the model is wrong?**
The user always confirms or changes the material before anything is saved. We log whether each decision was AI-confirmed, AI-corrected or manual, which tells us how accurate the AI is in real use.

**What if the model doesn't load?**
The app shows a clear warning and switches to manual selection. It never shows a fake prediction or score.

**Why ask questions instead of letting the AI decide the stream?**
The stream depends on condition and past use, not just material. A camera can't see food residue or tell that a tissue was used for hygiene. Five yes/no checks plus a rules engine handle that.

**What's the tech stack?**
Python, Streamlit (frontend and backend in one file), SQLite, ONNX Runtime, NumPy, Pandas, Plotly and Pillow. No React, no separate server, no Docker, no paid APIs.

**Does it need internet?**
No. The model and database are on the laptop. Internet is only needed once to install the Python packages.

**Where is the data stored?**
In a local SQLite file (`wastewise.db`) with three tables: pickups, status_log (audit trail) and scans. It is created automatically on first run and survives restarts.

### Data integrity

**How do you stop fake recycling numbers?**
Three rules in code. Status must go in order (no recovery before collection). Recovered weight can't exceed collected weight. Recovery needs an evidence file, a receipt number or an explicit SIMULATED tick, and simulated amounts are shown separately.

**What's the difference between reported, collected and recovered?**
Reported is the requester's estimate. Collected is what the collector weighed. Recovered is what a facility confirmed with evidence. Only the third counts as recycled.

**Why isn't sanitary waste counted as recovered?**
Sanitary waste is safely disposed (for example incinerated), not recycled. Counting it would inflate the numbers.

**How do judges know which data is demo data?**
Every demo record is flagged and shows a yellow DEMO DATA badge. A toggle removes demo data from all numbers and charts, and it can be cleared without touching real records.

**Can someone upload a fake receipt?**
In the MVP, yes. Evidence is stored for audit, not verified automatically. Next steps are recycler logins that upload slips directly and OCR checks on receipts.

### Deployment and impact

**How would you deploy it on a campus?**
Run it on one existing PC or a cheap mini-PC on the campus network. Put QR codes at bin clusters so students open it on their phones. Housekeeping staff use it as collectors, and the scrap dealer's or MRF's weighment slip is the evidence.

**What does it cost?**
Close to zero: no cloud bills, no API fees, no special hardware. The only cost is a PC if the campus doesn't have a spare one.

**What impact can you measure?**
Kilograms reported, collected and verifiably recovered, recovery rate, pending pickups, items flagged for review, sanitary waste safely disposed, AI-assisted vs manual scans, and hotspot locations.

**How does it scale beyond one campus?**
Move the database to Postgres, add logins for each role, and give each campus or ward its own location list. The workflow and metrics fit municipal reporting and plastic EPR tracking.

### Tough questions on limitations

**What's the biggest weakness?**
ImageNet lacks waste-specific classes like crushed cans, flat cardboard and chips packets, so those often come back as low confidence. Manual confirmation covers this today, and fine-tuning on Indian waste photos is the fix.

**How accurate is the model?**
We haven't measured accuracy on a waste dataset yet, so we won't quote a number. In our tests it was highly confident on food items and correctly said "not recognised" for a photo of dogs. The scan log (confirmed vs corrected) will give us real accuracy data.

**There's no login. Can't anyone mark things collected?**
Yes, by design for the MVP, to keep the demo simple. Every change goes into the audit trail, and role-based logins are the first thing we'd add.

**Weights are typed in. Can't they be wrong?**
Yes. Reported weight is clearly labelled an estimate. Collected weight should come from a scale, and scale integration is a future step.

**Isn't this just a CRUD app with a classifier?**
The value is the closed loop and the honesty rules: context-aware stream decisions, enforced workflow, evidence-gated recovery and separate demo data. Those are what turn reported numbers into verified ones.

**What would you build next?**
Fine-tune the model on TrashNet, TACO and Indian waste photos. Add logins and WhatsApp or SMS alerts, collector route optimisation, a recycler portal with OCR receipt checks, CO2-saved estimates and hostel leaderboards.

## Last-minute cheat sheet

**Numbers to remember**

| Fact | Value |
| --- | --- |
| Model | EfficientNet-Lite0, pretrained on ImageNet |
| Object types the model knows | 1,000 |
| Object types mapped to materials | About 150, into 10 materials |
| Model size | 18 MB, runs offline |
| Time per photo | Under 50 ms on a laptop CPU |
| Suggestion threshold | 45% or more |
| Ask-to-confirm range | 20% to 45% |
| "Not recognised" | Under 20% |
| Context checks | 5 yes/no questions |
| Waste streams | 4: wet, dry, sanitary, special-care |
| Workflow | Reported, Accepted, Collected, Recovery Confirmed |
| Evidence types | File upload, receipt number, or SIMULATED (shown separately) |
| Demo records | 28, all labelled DEMO DATA |

**Phrases to use**

- "Most apps identify waste. We track it until it's recovered, with proof."
- "Reported, collected and recovered are three different numbers."
- "The AI suggests, the human confirms."
- "It doesn't guess. When it isn't sure, it says so."
- "Runs on one campus PC, no cloud, no API costs."

**Never claim**

- An accuracy percentage. We haven't measured one on waste images.
- That we trained the model ourselves. It's pretrained, and we built the mapping, rules and workflow.
- That evidence is verified automatically. It's stored for audit.
- That demo data is real. Always call it demo data.
